#include "nic.h"
#include "e1000.h"
#include "types.h"
#include "user.h"


int main(void)
{
    icmptest(1,2);
    exit();
}