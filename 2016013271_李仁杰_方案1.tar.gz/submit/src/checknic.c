#include "nic.h"
#include "e1000.h"
#include "types.h"
#include "user.h"


int main(void)
{
    int a=1,b=1;
    checknic(a,b);
    exit();
}